import * as React from 'react'
import { Bar } from 'react-chartjs-2';
import { useState } from 'react';

const BarChart = (): JSX.Element =>{

    return(
        <div>
            <p>opai</p>
        </div>
    )
}

export default BarChart;