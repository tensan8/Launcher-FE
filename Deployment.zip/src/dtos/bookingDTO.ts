export interface BookingDTO {
    tableId: number,
    userId: number,
    bookingDate: string,
    bookingStartTime: string,
    bookingEndTime: string
}