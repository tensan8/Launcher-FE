export interface UserDTO {
    userId: number
    cardUUID: number
    username: string
    password: string
    role: string
}
