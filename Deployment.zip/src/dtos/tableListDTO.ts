import { tableListStatus } from '../type'

export interface TableListDTO {
  tableId: number
  status: tableListStatus
}
