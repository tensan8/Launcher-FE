export interface SnackOrderDTO {
    itemId: number
    ownerId: number
    quantity: number
}