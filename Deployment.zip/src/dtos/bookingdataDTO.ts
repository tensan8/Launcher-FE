export interface BookingDayDTO {
    Day: number,
    total: number
}