export interface SnackDTO {
    snackId: number,
    name: string,
    price: number,
    currentStock: number,
    imageURL: string
}
