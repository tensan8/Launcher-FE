export interface OrderListDTO{
    SnackName: string,
    totalQuantity:number
  }