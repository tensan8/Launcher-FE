declare module 'mqtt/dist/mqtt' {
  import MQTT from 'mqtt'
  export = MQTT
}

declare module 'paho-mqtt'